package sejmometr;

//import java.lang.*;
import java.io.IOException;
//import java.util.List;

public class SpendingSystem {
    public static void main(String[] args) {
        try {
        	System.out.println("Trwa obliczanie...");
            long start = System.nanoTime();

            new SpendingCalculator().calculate(args);

            long end = System.nanoTime();

            System.out.println("\nCzas wykonania: " + (int) ((end - start) / 1000000000.0) + " s");

        } catch (IllegalArgumentException err) {
            System.out.println(err.getMessage());
            System.out.println("Poprawna sk�adnia to: ");
            System.out.println("-k 7|8 -o 1..7 [Imi� Nazwisko]");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
