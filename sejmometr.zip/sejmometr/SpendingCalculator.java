package sejmometr;

import java.io.IOException;
import java.util.List;
//import java.lang.*;
import java.text.DecimalFormat;

public class SpendingCalculator {
    private static DecimalFormat decimalFormat = new DecimalFormat();

    SpendingCalculator(){
        decimalFormat.setMaximumFractionDigits(2);
    }

    public void calculate(java.lang.String[] args) throws IOException{
        OptionParser userOptions = new OptionParser().getUserOptions(args);
        Parliament p = new JsonDeputy().getAllDeputies(userOptions.getCadence());

        switch(userOptions.getOption()){
            case DeputySpending:
            	this.calcDeputySpending(p, userOptions.getName());
                break;

            case RepairsSpending:
                this.calcRepairsSpending(p, userOptions.getName());
                break;

            case CadenceAverage:
                this.calcAverage(p);
                break;

            case MostForeignTrips:
                this.calcMostTrips(p);
                break;

            case LongestAbroad:
                this.calcLongestAbroad(p);
                break;

            case MostExpensiveTrip:
                this.calcMostExpensiveTrip(p);
                break;

            case TourToItaly:
                this.calcTourToItaly(p);
                break;
        }
    }

    private List<Spending> spendingList(Parliament parliament, String deputyName) throws IOException{
        Deputy deputy = new Deputy();
        for(Deputy d : parliament.getCadenceDeputiesList()) {
            if (d.getName().equals(deputyName)){
                deputy = d;
                break;
            }
        }

        if(deputy.getName() == null)
            throw new IllegalArgumentException(deputyName + " nie by� pos�em w tej kadencji.");

        deputy.setSpending(new JsonSpending().getDeputySpending(deputy.getId()));
        return deputy.getSpending();
    }

    //-----1-----
    private void calcDeputySpending(Parliament parliament, String deputyName) throws IOException {
    	spendingList(parliament, deputyName);

        Deputy deputy = parliament.getDeputy(deputyName);
        Double sum = 0.0;

        List<Spending> deputySpending = deputy.getSpending();

        for (Spending spending : deputySpending) {
            sum += spending.getSpendingSum();
        }
             System.out.println("Wszystkie wydatki pos�a " + deputyName + ": " + decimalFormat.format(sum) + " z�");
    }

    //-----2-----
    private void calcRepairsSpending(Parliament parliament, String deputyName) throws IOException {
        spendingList(parliament, deputyName);

        Deputy deputy = parliament.getDeputy(deputyName);
        List<Spending> deputySpending = deputy.getSpending();

        Double result = 0.0;

        for (Spending spending : deputySpending) {
            int id = spending.getTitles().getTitleID("Koszty drobnych napraw i remont\u00f3w lokalu biura poselskiego");
            if (id == -1)
                result += 0.0;
            else
                result += spending.getSpending(id);
        }
        System.out.println("Wydatki na naprawy pos�a" + deputyName + " " + decimalFormat.format(result) + " z�");
    }
    
    //-----3-----
    private void calcAverage(Parliament parliament) throws IOException {
        Double sum = 0.0;

        for(Deputy d : parliament.getCadenceDeputiesList()){
            for (Spending s : d.getSpending())
                sum += s.getSpendingSum();
        }
        int count = parliament.getCadenceDeputiesList().size();
        System.out.println("�rednie wydatki pos��w: " + decimalFormat.format(sum / count) + " z�.");
    }

    //-----4-----
    private void calcMostTrips(Parliament parliament) throws IOException{
        new JsonTrips().getTripsInfo(parliament);

        String name = "";
        int trips = 0;

        for(Deputy deputy : parliament.getCadenceDeputiesList()){
           if(deputy.getTrips().getTripsCount() > trips){ //nie uwzgl�dnia kilku pos��w z najwi�ksz� liczb� wyjazd�w
               trips = deputy.getTrips().getTripsCount();
               name = deputy.getName();
           }
        }

        System.out.println("Najwi�cej wyjazd�w odby� pose� " + name + ". ��cznie " + trips + " wyjazdy.");
    }

    //-----5-----
    private void calcLongestAbroad(Parliament parliament) throws IOException{
        new JsonTrips().getTripsInfo(parliament);

        String name = "";
        int days = 0;

        for(Deputy deputy : parliament.getCadenceDeputiesList()){
            if(deputy.getTrips().getLongestTripDaysCount() > days){  //nie uwzgl�dnia kilku pos��w z najd�u�szym wyjazdem
                days = deputy.getTrips().getLongestTripDaysCount();
                name = deputy.getName();
            }
        }
        System.out.println("Najd�u�sz� podr� odby� " + name + ". Trwa�a " + days + " dni.");
    }

    //-----6-----
    private void calcMostExpensiveTrip(Parliament parliament) throws IOException{
        new JsonTrips().getTripsInfo(parliament);

        String name = "";
        Double cost = 0.0;

        for(Deputy deputy : parliament.getCadenceDeputiesList()){
            if(deputy.getTrips().getMostExpensiveTripsCost() > cost){
                cost = deputy.getTrips().getMostExpensiveTripsCost();
                name = deputy.getName();
            }
        }

        System.out.println("Najdro�sza podr� odby� pose� " + name + ". Kosztowa�a " + decimalFormat.format(cost) + " z�.");
    }
        
    //-----7-----
    private void calcTourToItaly(Parliament parliament) throws IOException{
        List<Deputy> deputiesInItaly = new JsonTrips().getTripsInfo(parliament).getDeputiesInItaly();

        System.out.println("\nLista pos��w, kt�rzy odbyli podr� do W�och:");
        for(Deputy d : deputiesInItaly)
            System.out.println(d.getName());
    }
}
