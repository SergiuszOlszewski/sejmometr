package sejmometr;

public class SpendingPrinter {
}
