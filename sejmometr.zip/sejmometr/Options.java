package sejmometr;

enum Options {
    DeputySpending,
    RepairsSpending,
    CadenceAverage,
    MostForeignTrips,
    LongestAbroad,
    MostExpensiveTrip,
    TourToItaly
}
